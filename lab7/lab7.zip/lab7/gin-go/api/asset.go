package api

import (
	"encoding/json"
	"net/http"
	"strconv"
	"fmt"
	"gin-app/fabric"

	"github.com/gin-gonic/gin"
)

func RegisterAssetRoutes(r *gin.Engine) {
	r.POST("/asset", CreateAsset)
	r.GET("/asset/:id", ReadAsset)
	r.GET("/assets", GetAllAssets)
}

type Asset struct {
	ID             string `json:"ID"`
	Color          string `json:"Color"`
	Size           int    `json:"Size"`
	Owner          string `json:"Owner"`
	AppraisedValue int    `json:"AppraisedValue"`
}

func CreateAsset(c *gin.Context) {
	var req Asset
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	_, err := fabric.Contract.SubmitTransaction("CreateAsset",
		req.ID, req.Color,
		strconv.Itoa(req.Size),
		req.Owner,
		strconv.Itoa(req.AppraisedValue),
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create asset: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Asset created successfully"})
}

func ReadAsset(c *gin.Context) {
	id := c.Param("id")

	result, err := fabric.Contract.EvaluateTransaction("ReadAsset", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to read asset: " + err.Error()})
		return
	}

	var asset Asset
	json.Unmarshal(result, &asset)

	c.JSON(http.StatusOK, asset)
}

func GetAllAssets(c *gin.Context) {
	result, err := fabric.Contract.EvaluateTransaction("GetAllAssets")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to get all assets: " + err.Error()})
		return
	}

	var assets []Asset
	json.Unmarshal(result, &assets)

	c.JSON(http.StatusOK, assets)
}

// 1. 初始化账本
func InitLedger(c *gin.Context) {
    // 调用 fabric.go 里的全局 Contract 对象执行链码的 InitLedger 函数
    _, err := fabric.Contract.SubmitTransaction("InitLedger")
    if err != nil {
        c.JSON(500, gin.H{"error": "Failed to initialize ledger: " + err.Error()})
        return
    }
    c.JSON(200, gin.H{"message": "Ledger initialized successfully!"})
}

// 2. 更新资产
func UpdateAsset(c *gin.Context) {
    var asset map[string]interface{}
    if err := c.ShouldBindJSON(&asset); err != nil {
        c.JSON(400, gin.H{"error": err.Error()})
        return
    }

    // 提交更新事务，传入链码所需的参数（必须为 string 类型）
    _, err := fabric.Contract.SubmitTransaction(
        "UpdateAsset", 
        asset["ID"].(string), 
        asset["Color"].(string), 
        fmt.Sprintf("%v", asset["Size"]), 
        asset["Owner"].(string), 
        fmt.Sprintf("%v", asset["AppraisedValue"]),
    )
    if err != nil {
        c.JSON(500, gin.H{"error": "Failed to update asset: " + err.Error()})
        return
    }
    c.JSON(200, gin.H{"message": "Asset updated successfully!"})
}

// 3. 删除资产
func DeleteAsset(c *gin.Context) {
    id := c.Param("id") // 从 URL 路由中获取绑定的资产 ID
    _, err := fabric.Contract.SubmitTransaction("DeleteAsset", id)
    if err != nil {
        c.JSON(500, gin.H{"error": "Failed to delete asset: " + err.Error()})
        return
    }
    c.JSON(200, gin.H{"message": "Asset " + id + " deleted successfully!"})
}
