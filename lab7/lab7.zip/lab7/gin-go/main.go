package main

import (
	"gin-app/api"
	"gin-app/fabric"

	"github.com/gin-gonic/gin"
)

func main() {
	fabric.InitFabric()

	r := gin.Default()
	api.RegisterAssetRoutes(r)

	// 以下是新增加的 3 个路由接口
	r.POST("/initLedger", api.InitLedger)
	r.PUT("/asset", api.UpdateAsset)
	r.DELETE("/asset/:id", api.DeleteAsset)

r.Run("0.0.0.0:8080")

}
